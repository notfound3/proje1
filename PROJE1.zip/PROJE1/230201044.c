#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct 
{
    char name[50];
    int saldiri;
    int savunma;
    int saglik;
    int kritik_sans;
} Unit;


Unit units[8];
int unit_count = 0;


void set_default_values(Unit *unit) 
{
    //strcpy( unit->name , " ");
    unit->saldiri = 0;
    unit->savunma = 0;
    unit->saglik = 0;
    unit->kritik_sans = 0;
}


void set_name_space(Unit *unit)
{
    strcpy(unit->name," ");
}


    int read_json(const char *filename) 
    {
    
    FILE *file = fopen(filename, "r");
    if (!file) 
    {
        printf("Hata: Dosya '%s' bulunamadı. Lütfen dosyanın doğru isimde ve doğru dizinde olduğundan emin olun.\n", filename);
        return -1;
    } 

    char line[256];
    int count = 0;
    Unit current_unit;
    set_default_values(&current_unit);

    while (fgets(line, sizeof(line), file)) 
    {
        line[strcspn(line, "\n")] = 0;  // Yeni satır karakterini kaldır

        if (strstr(line, "{")) 
        {
            // Birim adı
            sscanf(line, " \"%[^\"]\": {", current_unit.name); //İki tırnak arası her şeyi almak için
             set_default_values(&current_unit);
        } 
        else if (strstr(line, "saldiri")) 
        {
            sscanf(line, " \"saldiri\": %d,", &current_unit.saldiri);
        }
         else if (strstr(line, "savunma")) 
        {
            sscanf(line, " \"savunma\": %d,", &current_unit.savunma);
        } 
        else if (strstr(line, "saglik")) 
        {
            sscanf(line, " \"saglik\": %d,", &current_unit.saglik);
        } 
        else if (strstr(line, "kritik_sans")) 
        {
            sscanf(line, " \"kritik_sans\": %d,", &current_unit.kritik_sans);
        } 
        else if (strstr(line, "}") ) 
        {
            // Birim bitişi
            //if(!(count==4))
            // count ++;
            
            if(!(count == 4) && !(count == 9))
            {
                if (unit_count < 8 )
                 {
                units[unit_count++] = current_unit; // Birimi kaydet
                set_default_values(&current_unit); // Sıfırlama
                 }
            }
            count++;
            
        
        }
    }

       fclose(file);
       return 0;
}


void print_units() 
{
    for (int i = 0; i < unit_count; i++) 
    {
        printf("Birim: %s\n", units[i].name);
        printf("Saldiri: %d\n", units[i].saldiri);
        printf("Savunma: %d\n", units[i].savunma);
        printf("Saglik: %d\n", units[i].saglik);
        printf("Kritik Sans: %d\n", units[i].kritik_sans);
        printf("\n");
    }
    printf("Okunan Satır: \n");
    int i=0;

if (unit_count < 8) 
{
    printf("Birimi Kaydedildi: %s\n", units[i].name);
    printf("Toplam Birim Sayisi: %d\n", unit_count);
    // Sıfırlama
}

}


//UNİT.TYPES.JSON DOSYASI BURA BİTTİ


typedef struct 
{
   char name[50];
   char bonus_turu[20];
   char bonus_degeri[20];
   char aciklama[50];

} Unith;


Unith unit1[9];
int unit1_count = 0;


void set_heroes_space(Unith* unit1)
{
    strcpy(unit1 ->name," ");
}


int read_jsonh(const char *filename1)
{
   FILE *file1 = fopen(filename1, "r");
    if (!file1) 
    {
        printf("Hata: Dosya '%s' bulunamadı. Lütfen dosyanın doğru isimde ve doğru dizinde olduğundan emin olun.\n", filename1);
        return -1;
    }
 
   
  char lineh[256];
  int counth =0;
  Unith current_unith;
  
  while(fgets(lineh, sizeof(lineh), file1))
  {
     
     lineh[strcspn(lineh, "\n")] = 0;

       if(strstr(lineh, "{"))
       {
          sscanf(lineh, " \"%[^\"]\": {", current_unith.name); 
       }
       else if(strstr (lineh, "bonus_turu"))
       {
          sscanf(lineh, " \"bonus_turu\": \"%[^\"]\",", &current_unith.bonus_turu);
       }
       else if(strstr (lineh, "bonus_degeri"))
       {
          sscanf(lineh, " \"bonus_degeri\": \"%[^\"]\",", &current_unith.bonus_degeri);
       }
       else if(strstr (lineh, "aciklama"))
       {
          sscanf(lineh, " \"aciklama\": \"%[^\"]\",", current_unith.aciklama);
       }
       else if(strstr (lineh, "}"))
       {
          if(!(counth == 5) && !(counth == 10))
          {
            if(unit1_count < 9)
            {
                unit1[unit1_count++] = current_unith;
            }
          }
         
         counth++;
       }

    }
    
    fclose(file1);
    return 0;
}


void print_unit1()
{
    for (int i = 0; i < unit1_count; i++) 
    {
        printf("Kahraman: %s\n", unit1[i].name);
        printf("Bonus turu: %s\n", unit1[i].bonus_turu);
        printf("Bonus degeri: %s\n", unit1[i].bonus_degeri);
        printf("Aciklama: %s\n", unit1[i].aciklama);
        printf("\n");
    }
  
    int i=0;

if (unit_count < 9) 
{
    printf("Birimi Kaydedildi: %s\n", unit1[i].name);
    printf("Toplam Kahraman Sayisi: %d\n\n", unit1_count);
   
}
}


//HEROES.JSON DOSYASI BURDA BİTTİ


typedef struct
{
    char name[50];
    char etki_degeri[10];
    char etki_turu[20];
    char aciklama[50];
} Unitc;


Unitc unit2[11];
int unit2_count = 0;



void set_creatures_space(Unitc* unit2)
{
    strcpy(unit2 ->name, " ");
}


int read_jsonc(const char* filename2)
{
    FILE* file2=fopen(filename2, "r");
    if (!file2) 
    {
        printf("Hata: Dosya '%s' bulunamadı. Lütfen dosyanın doğru isimde ve doğru dizinde olduğundan emin olun.\n", filename2);
        return -1;
    }


  char linec[256];
  int countc = 0;
  Unitc current_unitc;

  while(fgets(linec, sizeof(linec), file2))
  {
     linec[strcspn(linec, "\n")] = 0;

      if(strstr(linec, "{"))
      {
        sscanf(linec, " \"%[^\"]\": {", current_unitc.name); 
      }
      else if(strstr(linec, "etki_degeri"))
      {
        sscanf(linec, " \"etki_degeri\": \"%[^\"]\",", &current_unitc.etki_degeri);
      }
      else if(strstr(linec, "etki_turu"))
      {
        sscanf(linec, " \"etki_turu\": \"%[^\"]\",", &current_unitc.etki_turu);
      }
      else if(strstr(linec, "aciklama"))
      {
        sscanf(linec, " \"aciklama\": \"%[^\"]\",", current_unitc.aciklama);
      }
      else if(strstr(linec, "}"))
      {
         if(!(countc == 5) && !(countc == 12))
         {
            if(unit2_count <11)
            {
                unit2[unit2_count++] = current_unitc;
            }
         }

         countc++;

      }


 }
    
    fclose(file2);
    return 0;
}


void print_unit2()
{
    for(int i=0; i< unit2_count; i++)
    {
        printf("Yaratik: %s\n", unit2[i].name);
        printf("Etki degeri: %s\n", unit2[i].etki_degeri);
        printf("Etki turu: %s\n", unit2[i].etki_turu);
        printf("Aciklama: %s\n", unit2[i].aciklama);
        printf("\n");
    }
    printf("Okunan Satır: ");
    int i=0;
   
   
   if (unit2_count < 11) 
    {
    printf("Birimi Kaydedildi: %s\n", unit2[i].name);
    printf("Toplam Yaratik Sayisi: %d\n", unit2_count);
   
    }

}


// CRESTURES.JSON DOSYASI BURDA BİTTİ


typedef struct 
{
   char name[50];
   char level[10];
   char deger[10];
   char aciklama[100];

} Unitr;


Unitr unit3[12];
int unit3_count = 0;


void set_research_space(Unitr* unit3)
{
    strcpy(unit3 ->name, " ");
}


int read_jsonr(const char* filename3)
{
    FILE* file3 = fopen(filename3, "r");
    if(!file3)
    {
        printf("Hata: Dosya '%s' bulunamadı. Lütfen dosyanın doğru isimde ve doğru dizinde olduğundan emin olun.\n", filename3);
        return -1;
    }


  char liner[256];
  char current_skill[50];
  char current_level[10];
  int countr = 0;
  Unitr current_unitr;

  while (fgets(liner, sizeof(liner), file3)) 
  {
        
        if (strstr(liner, "{") || strstr(liner, "}") ) 
        {
            continue;
        }
        
        else if 
        (strlen(liner) > 0 && 
                (strstr(liner, "savunma_ustaligi") || 
                 strstr(liner, "saldiri_gelistirmesi") || 
                 strstr(liner, "elit_egitim") || 
                 strstr(liner, "kusatma_ustaligi"))) {
            sscanf(liner, " \"%[^\"]\": {", current_skill);
        }
      
        else if (strstr(liner, "seviye")) 
        {
             sscanf(liner, " \"seviye\": \"%[^\"]\",", current_level);
            strcpy(current_unitr.name, current_skill);
            strcpy(current_unitr.level, current_level);
        }
    
        else if (strstr(liner, "deger")) 
        {
            sscanf(liner, " \"deger\": \"%[^\"]\",", current_unitr.deger);
        }
      
        else if (strstr(liner, "aciklama"))
        {
            sscanf(liner, " \"aciklama\": \"%[^\"]\",", current_unitr.aciklama);
        }
        else if (strstr(liner, "}")) 
        {
           if (unit3_count < 12) {
                unit3[unit3_count++] = current_unitr; 
            }

        }
        
    }

    fclose(file3);
    return 0;
}



void print_unit3()
{
    for(int i=0; i< unit3_count; i++)
    {
        printf("Beceri: %s\n", unit3[i].name);
        printf("Seviye: %s\n", unit3[i].level);
        printf("Degeri: %s\n", unit3[i].deger);
        printf("Aciklama: %s\n", unit3[i].aciklama);
        printf("\n");
    }
    printf("Toplam arastirma sayisi: %d\n", unit3_count);
    

}


// JSON OKUTMA BURDA BİTİYOR



int main() {
    const char *filename = "Files/unit_types.json";
    const char *filename1 = "Files/heroes.json";
    const char *filename2 = "Files/creatures.json";
    const char *filename3 = "Files/research.json";



    if (read_json(filename) == 0) {
        print_units();
    }

    if(read_jsonh(filename1) == 0)
    {
        print_unit1();
    }

    if(read_jsonc(filename2) == 0)
    {
        print_unit2();
    }

    if(read_jsonr(filename3) == 0)
    {
        print_unit3();
    }

   


    return 0;
}



