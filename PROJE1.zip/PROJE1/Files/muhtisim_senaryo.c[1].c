#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct InsanImparatorlugu {
    char kahraman[50];   // Sadece bir kahraman
    char canavar[30]; 
    char arastirma[30];   // Sadece bir canavar
    int okcular;
    int piyadeler;
    int kusatma_makineleri;
    int suvariler;
    int savunma_ustaligi;
    int saldiri_gelistirmesi;
    int elit_egitim;
    int kusatma_ustaligi;
    int arastirma_degeri;


};

struct OrkLegi {
    char kahraman[50];   // Sadece bir kahraman
    char canavar[30]; 
    char arastirma[30];  
    int mizrakcilar;
    int orkDovuscileri;
    int troller;
    int vargBinicileri;
    int savunma_ustaligi;
    int saldiri_gelistirmesi;
    int elit_egitim;
    int kusatma_ustaligi;
    int arastirma_degeri;
};


void parseInsanImparatorlugu(const char* jsonString, struct InsanImparatorlugu* insan) {
    const char *insanSection = strstr(jsonString, "\"insan_imparatorlugu\": {");
    if (insanSection) {
        insanSection += strlen("\"insan_imparatorlugu\": {");

        // Kahraman
        const char *kahramanStart = strstr(insanSection, "\"kahramanlar\": [");
        if (kahramanStart) {
            kahramanStart += strlen("\"kahramanlar\": [");
            sscanf(kahramanStart, " \"%[^\"]\"", insan->kahraman);
        }

        // Canavar
        const char *canavarStart = strstr(insanSection, "\"canavarlar\": [");
        if (canavarStart) {
            canavarStart += strlen("\"canavarlar\": [");
            sscanf(canavarStart, " \"%[^\"]\"", insan->canavar);
        }

        const char *arastirmaSeviyesiStart = strstr(insanSection, "\"arastirma_seviyesi\": {");
        if(arastirmaSeviyesiStart)
        {
            arastirmaSeviyesiStart +=  strlen("\"arastirma_seviyesi\": {");
            if(strstr(arastirmaSeviyesiStart, "\"savunma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"savunma_ustaligi\": %d,", &insan->arastirma_degeri);
                strcpy(insan->arastirma, "savunma_ustaligi");
            }
            if(strstr(arastirmaSeviyesiStart, "\"saldiri_gelistirmesi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"saldiri_gelistirmesi\": %d,", &insan->arastirma_degeri);
                strcpy(insan->arastirma, "saldiri_gelistirmesi");
            }
            if(strstr(arastirmaSeviyesiStart, "\"elit_egitim\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"elit_egitim\": %d,", &insan->arastirma_degeri);
                strcpy(insan->arastirma, "elit_egitim");
            }
            if(strstr(arastirmaSeviyesiStart, "\"kusatma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"kusatma_ustaligi\": %d,", &insan->arastirma_degeri); 
                strcpy(insan->arastirma, "kusatma_ustaligi");
            }
        }


       // Birimler
const char *birimlerStart = strstr(insanSection, "\"birimler\": {");
if (birimlerStart) {
    birimlerStart += strlen("\"birimler\": {");
    char temp[50];
    //strcpy(temp, birimlerStart);
    printf("%s",temp);
    char  *okcuStart,*piyadeStart, *kusatmaStart, *suvariStart;
    
    // Okçular
    okcuStart = strstr(birimlerStart, "\"okcular\":");
    if(okcuStart){
        sscanf(okcuStart, " \"okcular\": %d,", &insan->okcular);
    }
    
    piyadeStart = strstr(birimlerStart, "\"piyadeler\":");
    if (piyadeStart) {
        sscanf(piyadeStart, " \"piyadeler\": %d,", &insan->piyadeler);
    }

 
    kusatmaStart = strstr(birimlerStart, "\"kusatma_makineleri\":");
    if (kusatmaStart) {
        sscanf(kusatmaStart, " \"kusatma_makineleri\": %d,", &insan->kusatma_makineleri);
    }

    
    suvariStart = strstr(birimlerStart, "\"suvariler\":");
    if (suvariStart) {
        sscanf(suvariStart, " \"suvariler\": %d,", &insan->suvariler);
    }
}

    }

}

void parseOrkLegi(const char* jsonString, struct OrkLegi* ork) {
    const char *orkSection = strstr(jsonString, "\"ork_legi\": {");
    if (orkSection) {
        orkSection += strlen("\"ork_legi\": {");

        // Kahraman
        const char *kahramanStart = strstr(orkSection, "\"kahramanlar\": [");
        if (kahramanStart) {
            kahramanStart += strlen("\"kahramanlar\": [");
            sscanf(kahramanStart, " \"%[^\"]\"", ork->kahraman);
        }

        // Canavar
        const char *canavarStart = strstr(orkSection, "\"canavarlar\": [");
        if (canavarStart) {
            canavarStart += strlen("\"canavarlar\": [");
            sscanf(canavarStart, " \"%[^\"]\"", ork->canavar);
        }
        
        const char *arastirmaSeviyesiStart = strstr(orkSection, "\"arastirma_seviyesi\": {");
        if(arastirmaSeviyesiStart)
        {
            arastirmaSeviyesiStart +=  strlen("\"arastirma_seviyesi\": {");
            if(strstr(arastirmaSeviyesiStart, "\"savunma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"savunma_ustaligi\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "savunma_ustaligi");
            }
            if(strstr(arastirmaSeviyesiStart, "\"saldiri_gelistirmesi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"saldiri_gelistirmesi\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "saldiri_gelistirmesi");
            }
            if(strstr(arastirmaSeviyesiStart, "\"elit_egitim\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"elit_egitim\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "elit_egitim");
            }
            if(strstr(arastirmaSeviyesiStart, "\"kusatma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"kusatma_ustaligi\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "kusatma_ustaligi"); 
            }
        }
       // Birimler
const char *birimlerStart = strstr(orkSection, "\"birimler\": {");
if (birimlerStart) {
    birimlerStart += strlen("\"birimler\": {");

    char *mizrakStart, *orkDovuscileriStart, *trollerStart, *vargStart;

    mizrakStart = strstr(birimlerStart, "\"mizrakcilar\":");
    if(mizrakStart){
    sscanf(mizrakStart, " \"mizrakcilar\": %d,", &ork->mizrakcilar);}
    
    orkDovuscileriStart = strstr(birimlerStart, "\"ork_dovusculeri\":");
    if (orkDovuscileriStart) {
        sscanf(orkDovuscileriStart, " \"ork_dovusculeri\": %d,", &ork->orkDovuscileri);
    }

  
    trollerStart = strstr(birimlerStart, "\"troller\":");
    if (trollerStart) {
        sscanf(trollerStart, " \"troller\": %d,", &ork->troller);
    }

    vargStart = strstr(birimlerStart, "\"varg_binicileri\":");
    if (vargStart) {
        sscanf(vargStart, " \"varg_binicileri\": %d,", &ork->vargBinicileri);
    }
}

    }
}

int main() {
    FILE *file = fopen("8.json", "r");
    if (!file) {
        perror("File opening failed");
        return EXIT_FAILURE;
    }

    // Dosyadan JSON verisini oku
    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);
    char *jsonString = malloc(length + 1);
    fread(jsonString, 1, length, file);
    fclose(file);
    jsonString[length] = '\0'; // Sonlandırıcı ekle

    struct InsanImparatorlugu insan;
    memset(&insan, 0, sizeof(insan));
    parseInsanImparatorlugu(jsonString, &insan);

    struct OrkLegi ork;
    memset(&ork, 0, sizeof(ork));
    parseOrkLegi(jsonString, &ork);

    // Sonuçları yazdır
    printf("Insan Imparatorlugu\n");
    printf("insan Kahramani: %s\n", insan.kahraman);
    printf("insan Canavari: %s\n", insan.canavar);
    printf("Birimler:\n");
    printf("  Okcular: %d\n", insan.okcular);
    printf("  Piyadeler: %d\n", insan.piyadeler);
    printf("  Kusatma Makineleri: %d\n", insan.kusatma_makineleri);
    printf("  Suvariler: %d\n", insan.suvariler);
    printf("arastirma Seviyesi:\n");
    printf("arastirma: %s\n", insan.arastirma);
    printf("  Degeri: %d\n", insan.arastirma_degeri);


    printf("\nOrk Kahramani: %s\n", ork.kahraman);
    printf("Ork Canavari: %s\n", ork.canavar);
    printf("Birimler:\n");
    printf("  Mizrakcilar: %d\n", ork.mizrakcilar);
    printf("  Ork Dovusculeri: %d\n", ork.orkDovuscileri);
    printf("  Troller: %d\n", ork.troller);
    printf("  Varg Binicileri: %d\n", ork.vargBinicileri);
    printf("arastirma Seviyesi:\n");
    printf("arastirma: %s\n", ork.arastirma);
    printf("  Degeri: %d\n", ork.arastirma_degeri);
    
    free(jsonString);
    return 0;
}
