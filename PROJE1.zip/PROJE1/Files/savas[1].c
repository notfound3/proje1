
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int count =0;


struct OrkLegi {
    char kahraman[50];   
    char canavar[30];
    char arastirma[30];    
    int mizrakcilar;
    int orkDovuscileri;
    int troller;
    int vargBinicileri;
    int savunma_ustaligi;
    int saldiri_gelistirmesi;
    int elit_egitim;
    int kusatma_ustaligi;
    int arastirma_degeri;
};

struct InsanImparatorlugu {
    char kahraman[50];   
    char canavar[30];
    char arastirma[30];    
    int okcular;
    int piyadeler;
    int kusatma_makineleri;
    int suvariler;
    int savunma_ustaligi;
    int saldiri_gelistirmesi;
    int elit_egitim;
    int kusatma_ustaligi;
    int arastirma_degeri;
};
struct Unit {
    char name[50];
    int saldiri;
    int savunma;
    int saglik;
    int kritik_sans;
};

struct Unit units[8];

struct Hero{
    char name[50];
    char bonus_turu[20];
    char bonus_degeri[20];
    char aciklama[50];
};

struct Hero heroes[9];

struct Creature {
    char name[50];
    char etki_degeri[10];
    char etki_turu[20];
    char aciklama[50];
};

 struct Creature creatures[11];

struct Research {
    char name[50];
    char deger[10];
    char aciklama[50];
};

struct Research researchs[12];

void set_default_values(struct Unit *unit) {
    unit->saldiri = 0;
    unit->savunma = 0;
    unit->saglik = 0;
    unit->kritik_sans = 0;
}


int read_json(const char *filename, struct Unit *units) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename);
        return -1;
    }
    int unit_count = 0;
    char line[256];
   struct Unit current_unit;
    set_default_values(&current_unit);

    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = 0; // Yeni satır karakterini kaldır

        if (strstr(line, "{")) {
            sscanf(line, " \"%[^\"]\": {", current_unit.name);
            set_default_values(&current_unit);
        } else if (strstr(line, "saldiri")) {
            sscanf(line, " \"saldiri\": %d,", &current_unit.saldiri);
        } else if (strstr(line, "savunma")) {
            sscanf(line, " \"savunma\": %d,", &current_unit.savunma);
        } else if (strstr(line, "saglik")) {
            sscanf(line, " \"saglik\": %d,", &current_unit.saglik);
        } else if (strstr(line, "kritik_sans")) {
            sscanf(line, " \"kritik_sans\": %d,", &current_unit.kritik_sans);
        } else if (strstr(line, "}"))
        {
            if(!(count == 4) && !( count == 9))
            {
                if(unit_count < 8)
                {
                    units[unit_count] = current_unit; // Birimi kaydet
                    unit_count++;
                }
            }
            count++;
        }
    }
    count = 0;
    fclose(file);
    return 0;
}


int hero_json(const char *filename1,struct Hero *heroes) {
    FILE *file1 = fopen(filename1, "r");
    if (!file1) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename1);
        return -1;
    }
    int hero_count = 0;
    char line_hero[256];
    struct Hero current_unith;

    while (fgets(line_hero, sizeof(line_hero), file1)) {
        line_hero[strcspn(line_hero, "\n")] = 0;

        if (strstr(line_hero, "{")) {
            sscanf(line_hero, " \"%[^\"]\": {", current_unith.name);
        } else if (strstr(line_hero, "bonus_turu")) {
            sscanf(line_hero, " \"bonus_turu\": \"%[^\"]\",", current_unith.bonus_turu);
        } else if (strstr(line_hero, "bonus_degeri")) {
            sscanf(line_hero, " \"bonus_degeri\": \"%[^\"]\",", current_unith.bonus_degeri);
        } else if (strstr(line_hero, "aciklama")) {
            sscanf(line_hero, " \"aciklama\": \"%[^\"]\",", current_unith.aciklama);
        } else if (strstr(line_hero, "}")) {

            if( !(count == 4) )
            {
                if (hero_count < 9)
                 {
                     heroes[hero_count++] = current_unith;
                 }
            }
            count++;
        }
    }
    count = 0;
    fclose(file1);
    return 0;
}


int creatures_json(const char *filename2,struct Creature *creatures) {
    FILE *file2 = fopen(filename2, "r");
    if (!file2) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename2);
        return -1;
    }
    int creature_count = 0;
    char line_c[256];
    struct Creature current_unitc;

    while (fgets(line_c, sizeof(line_c), file2)) {
        line_c[strcspn(line_c, "\n")] = 0;

        if (strstr(line_c, "{")) {
            sscanf(line_c, " \"%[^\"]\": {", current_unitc.name);
        } else if (strstr(line_c, "etki_degeri")) {
            sscanf(line_c, " \"etki_degeri\": \"%[^\"]\",", current_unitc.etki_degeri);
        } else if (strstr(line_c, "etki_turu")) {
            sscanf(line_c, " \"etki_turu\": \"%[^\"]\",", current_unitc.etki_turu);
        } else if (strstr(line_c, "aciklama")) {
            sscanf(line_c, " \"aciklama\": \"%[^\"]\",", current_unitc.aciklama);
        } else if (strstr(line_c, "}")) {
            if(!(count == 4))

            {
                if (creature_count < 11)
                {
                     creatures[creature_count++] = current_unitc;
                }
            }
            count++;
        }
    }
    count = 0;
    fclose(file2);
    return 0;
}


int research_json(const char *filename3,struct Research *researchs) {
    FILE *file3 = fopen(filename3, "r");
    int researchs_count = 0;
    if (!file3) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename3);
        return -1;
    }

    char line_r[256];
    struct Research current_unitr;

    while (fgets(line_r, sizeof(line_r), file3)) {
        line_r[strcspn(line_r, "\n")] = 0;

        if (strstr(line_r, "{")) {
            sscanf(line_r, " \"%[^\"]\": {", current_unitr.name);
        } else if (strstr(line_r, "deger")) {
            sscanf(line_r, " \"deger\": \"%[^\"]\",", current_unitr.deger);
        } else if (strstr(line_r, "aciklama")) {
            sscanf(line_r, " \"aciklama\": \"%[^\"]\",", current_unitr.aciklama);
        } else if (strstr(line_r, "}")) {

            if( !(count ==3) && !(count ==7) && !(count ==11)) 
            {
            
            if (researchs_count < 12) {
                researchs[researchs_count] = current_unitr;
                researchs_count++;
            }

            }
            count++;
        }
    }
    count = 0;
    fclose(file3);
    return 0;
}


void parseInsanImparatorlugu(const char* jsonString, struct InsanImparatorlugu *insan) {
    const char *insanSection = strstr(jsonString, "\"insan_imparatorlugu\": {");
    if (insanSection) {
        insanSection += strlen("\"insan_imparatorlugu\": {");

        // Kahraman
        const char *kahramanStart = strstr(insanSection, "\"kahramanlar\": [");
        if (kahramanStart) {
            kahramanStart += strlen("\"kahramanlar\": [");
            sscanf(kahramanStart, " \"%[^\"]\"", insan->kahraman);
        }

        // Canavar
        const char *canavarStart = strstr(insanSection, "\"canavarlar\": [");
        if (canavarStart) {
            canavarStart += strlen("\"canavarlar\": [");
            sscanf(canavarStart, " \"%[^\"]\"", insan->canavar);
        }

        const char *arastirmaSeviyesiStart = strstr(insanSection, "\"arastirma_seviyesi\": {");
        if(arastirmaSeviyesiStart)
        {
            arastirmaSeviyesiStart +=  strlen("\"arastirma_seviyesi\": {");
            if(strstr(arastirmaSeviyesiStart, "\"savunma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"savunma_ustaligi\": %d,", &insan->savunma_ustaligi);
            }
            if(strstr(arastirmaSeviyesiStart, "\"saldiri_gelistirmesi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"saldiri_gelistirmesi\": %d,", &insan->saldiri_gelistirmesi);
            }
            if(strstr(arastirmaSeviyesiStart, "\"elit_egitim\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"elit_egitim\": %d,", &insan->elit_egitim);
            }
            if(strstr(arastirmaSeviyesiStart, "\"kusatma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"kusatma_ustaligi\": %d,", &insan->kusatma_ustaligi); 
            }
        }


       // Birimler
const char *birimlerStart = strstr(insanSection, "\"birimler\": {");
if (birimlerStart) {
    birimlerStart += strlen("\"birimler\": {");
    
    char  *okcuStart,*piyadeStart, *kusatmaStart, *suvariStart;
    
    // Okçular
    okcuStart = strstr(birimlerStart, "\"okcular\":");
    if(okcuStart){
        sscanf(okcuStart, " \"okcular\": %d,", &insan->okcular);
    }
    
    piyadeStart = strstr(birimlerStart, "\"piyadeler\":");
    if (piyadeStart) {
        sscanf(piyadeStart, " \"piyadeler\": %d,", &insan->piyadeler);
    }

 
    kusatmaStart = strstr(birimlerStart, "\"kusatma_makineleri\":");
    if (kusatmaStart) {
        sscanf(kusatmaStart, " \"kusatma_makineleri\": %d,", &insan->kusatma_makineleri);
    }

    
    suvariStart = strstr(birimlerStart, "\"suvariler\":");
    if (suvariStart) {
        sscanf(suvariStart, " \"suvariler\": %d,", &insan->suvariler);
    }
}

    }

}



void parseOrkLegi(const char* jsonString, struct OrkLegi *ork) {
    const char *orkSection = strstr(jsonString, "\"ork_legi\": {");
    if (orkSection) {
        orkSection += strlen("\"ork_legi\": {");

        // Kahraman
        const char *kahramanStart = strstr(orkSection, "\"kahramanlar\": [");
        if (kahramanStart) {
            kahramanStart += strlen("\"kahramanlar\": [");
            sscanf(kahramanStart, " \"%[^\"]\"", ork->kahraman);
        }

        // Canavar
        const char *canavarStart = strstr(orkSection, "\"canavarlar\": [");
        if (canavarStart) {
            canavarStart += strlen("\"canavarlar\": [");
            sscanf(canavarStart, " \"%[^\"]\"", ork->canavar);
        }

        const char *arastirmaSeviyesiStart = strstr(orkSection, "\"arastirma_seviyesi\": {");
        if(arastirmaSeviyesiStart)
        {
            arastirmaSeviyesiStart +=  strlen("\"arastirma_seviyesi\": {");
            if(strstr(arastirmaSeviyesiStart, "\"savunma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"savunma_ustaligi\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "savunma_ustaligi");
            }
            if(strstr(arastirmaSeviyesiStart, "\"saldiri_gelistirmesi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"saldiri_gelistirmesi\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "saldiri_gelistirmesi");
            }
            if(strstr(arastirmaSeviyesiStart, "\"elit_egitim\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"elit_egitim\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "elit_egitim");
            }
            if(strstr(arastirmaSeviyesiStart, "\"kusatma_ustaligi\""))
            {
                sscanf(arastirmaSeviyesiStart, " \"kusatma_ustaligi\": %d,", &ork->arastirma_degeri);
                strcpy(ork->arastirma, "kusatma_ustaligi");
            }
        }
       // Birimler
const char *birimlerStart = strstr(orkSection, "\"birimler\": {");
if (birimlerStart) {
    birimlerStart += strlen("\"birimler\": {");

    char *mizrakStart, *orkDovuscileriStart, *trollerStart, *vargStart;

    mizrakStart = strstr(birimlerStart, "\"mizrakcilar\":");
    if(mizrakStart){
    sscanf(mizrakStart, " \"mizrakcilar\": %d,", &ork->mizrakcilar);}

    orkDovuscileriStart = strstr(birimlerStart, "\"ork_dovusculeri\":");
    if (orkDovuscileriStart) {
        sscanf(orkDovuscileriStart, " \"ork_dovusculeri\": %d,", &ork->orkDovuscileri);
    }


    trollerStart = strstr(birimlerStart, "\"troller\":");
    if (trollerStart) {
        sscanf(trollerStart, " \"troller\": %d,", &ork->troller);
    }

    vargStart = strstr(birimlerStart, "\"varg_binicileri\":");
    if (vargStart) {
        sscanf(vargStart, " \"varg_binicileri\": %d,", &ork->vargBinicileri);
    }
}

    }
}



float saldiri_insan( struct InsanImparatorlugu *insan, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs )
{


    float net_saldiri,piyade_saldiri,kusatma_saldiri,suvari_saldiri,okcu_saldiri;

    /* burada yorgunluk hesaplaması olcak her 5 turda bir tum birimlerin  saldiri gucunu %10 dusurecek
    k ilk 1 olacak sekilde gelecek ve her 5 turda bir artacak 
    if(tur == 5k)
    {
        units->saldiri *= 0.90f;
        (units + 1)->saldiri *= 0.90f;
        (units + 2)->saldiri *= 0.90f;
        (units + 3)->saldiri *= 0.90f;
        k++;
    }
   
    
    */
    
    if((strcmp(insan->kahraman,"Fatih_Sultan_Mehmet")==0))
    {
        (units+3)->saldiri *= 1.25f;  //kusatmamakinesi
    }
    if((strcmp(insan->kahraman,"Tugrul_Bey")==0))
    {
        (units + 1)->saldiri *= 1.20f; //okcu
    }

    //yavuz sultan selim kritik sans icin etkili oldugundan count diye bi değisken ver turda etkili olsun
    if((strcmp(insan-> kahraman,"Yavuz_Sultan_Selim"))==0) 
    {
        /* mesela boyle 15 turda bir kritik sansi etkili olsun
        i yi basta 1 olarak fonksiyona gonder sonra i yi arttır
        if(tur == (100 / 15)*i)
        {    i++;
            (units + 2)-> *= 1.50f; //suvari
        }*/
       
    }
   if((strcmp(insan->canavar,"Ejderha")==0))
    {
        units->saldiri *= 1.15f;  //piyade
    }
    if((strcmp(insan->canavar,"Tepegoz")==0))
    {
        (units + 1 )->saldiri *= 1.25f; //okcu
    }
    /* bu kosul kritik sansla alakalı 
     if((strcmp(insan->canavar,"Karakurt")==0))
    {
        (units + 1 )->saldiri *= 1.50f;
    }*/
    if(strcmp(insan->arastirma,"saldiri_gelistirmesi")==0)
    {
        if(insan->arastirma_degeri == 1)
        {
             units->saldiri *= 1.10f;
            (units + 1)->saldiri *= 1.10f;
            (units + 2)->saldiri *= 1.10f;
            (units + 3)->saldiri *= 1.10f;


        }
        else if(insan->arastirma_degeri == 2)
        {
            units->saldiri *= 1.20f;
            (units + 1)->saldiri *= 1.20f;
            (units + 2)->saldiri *= 1.20f;
            (units + 3)->saldiri *= 1.20f;
        }
        else if(insan->arastirma_degeri == 3)
        {
            units->saldiri *= 1.30f;
            (units + 1)->saldiri *= 1.30f;
            (units + 2)->saldiri *= 1.30f;
            (units + 3)->saldiri *= 1.30f;
        }

        if(strcmp(insan->arastirma,"elit_egitim")==0)
        {
            if(insan->arastirma_degeri == 1)
            {
                //tur sayisi 20nin katlari oldugunda etkili olsun
                /*
                units->saldiri *= 1.50f;
                (units + 1)->saldiri *= 1.50f;
                (units + 2)->saldiri *= 1.50f;
                (units + 3)->saldiri *= 1.50f;
                */
            }
            else if(insan->arastirma_degeri == 2)
            {
               //tur sayisi 10un katlari oldugunda etkili olsun
                /*
                units->saldiri *= 1.50f;
                (units + 1)->saldiri *= 1.50f;
                (units + 2)->saldiri *= 1.50f;
                (units + 3)->saldiri *= 1.50f;
                */ 
            }
            else if(insan->arastirma_degeri == 3)
            {
                //tur sayisi (100/15)in katlari oldugunda etkili olsun
                /*
                units->saldiri *= 1.50f;
                (units + 1)->saldiri *= 1.50f;
                (units + 2)->saldiri *= 1.50f;
                (units + 3)->saldiri *= 1.50f;
                */
            }
        }

        if(strcmp(insan->arastirma,"kusatma_ustaligi")==0) //kusatma ustalalarina saldiri bonusu veriyor sadece
        {
            if(insan->arastirma_degeri == 1)
            {
                (units + 3)->saldiri *= 1.10f;
            }
            else if(insan->arastirma_degeri == 2)
            {
                (units + 3)->saldiri *= 1.20f;
            }
            else if(insan->arastirma_degeri == 3)
            {
                (units + 3)->saldiri *= 1.30f;
            }
            
        }

       
    }
    
    piyade_saldiri = (units->saldiri) * (insan->piyadeler);
    kusatma_saldiri = (units + 2)->saldiri * (insan->kusatma_makineleri);
    suvari_saldiri = (units + 3)->saldiri * (insan->suvariler);
    okcu_saldiri = (units + 1)->saldiri * (insan->okcular);
    net_saldiri = piyade_saldiri + kusatma_saldiri + suvari_saldiri + okcu_saldiri;
    
    return net_saldiri;   
}



float savunma_insan( struct InsanImparatorlugu *insan, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs )
{


    float net_savunma,piyade_savunma,kusatma_savunma,suvari_savunma,okcu_savunma;

    /* burada yorgunluk hesaplaması olcak her 5 turda bir tum birimlerin  saldiri gucunu %10 dusurecek
    k ilk 1 olacak sekilde gelecek ve her 5 turda bir artacak 
    if(tur == 5k)
    {
        units->savunma *= 0.90f;
        (units + 1)->savunma *= 0.90f;
        (units + 2)->savunma *= 0.90f;
        (units + 3)->savunma *= 0.90f;
        k++;
    }
   
    
    */
    if((strcmp(insan->kahraman,"Alparslan")==0))
    {
        units->savunma *= 1.20f;  //piyade
    }
    if((strcmp(insan->kahraman,"Mete_Han")==0))
    {
        (units + 1)->savunma *= 1.20f; //okcu
    }
   if((strcmp(insan->canavar,"Agri_Dagi_Devleri")==0))
    {
       (units + 2)->savunma *= 1.20f;  //suvariler
    }
    if((strcmp(insan->canavar,"Samur")==0))
    {
         units->savunma *= 1.10f;  //piyade
    }

    if(strcmp(insan->arastirma,"savunma_ustaligi")==0)
    {
        if(insan->arastirma_degeri == 1)
        {
             units->savunma *= 1.10f;
            (units + 1)->savunma *= 1.10f;
            (units + 2)->savunma *= 1.10f;
            (units + 3)->savunma *= 1.10f;
        }
       else if(insan->arastirma_degeri == 2)
        {
            units->savunma *= 1.20f;
            (units + 1)->savunma *= 1.20f;
            (units + 2)->savunma *= 1.20f;
            (units + 3)->savunma *= 1.20f;
        }
        else if(insan->arastirma_degeri == 3)
        {
            units->savunma *= 1.30f;
            (units + 1)->savunma *= 1.30f;
            (units + 2)->savunma *= 1.30f;
            (units + 3)->savunma *= 1.30f;
        }
    }

    
    
    piyade_savunma = (units->savunma) * (insan->piyadeler);
    kusatma_savunma = (units + 2)->savunma * (insan->kusatma_makineleri);
    suvari_savunma = (units + 3)->savunma * (insan->suvariler);
    okcu_savunma = (units + 1)->savunma * (insan->okcular);
    net_savunma = piyade_savunma + kusatma_savunma + suvari_savunma + okcu_savunma;
    return net_savunma;
}




float saldiri_ork( struct OrkLegi *ork, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs )
{


    float net_saldiri, mizrak_saldiri, orkDovuscileri_saldiri, troller_saldiri, varg_saldiri;

    
    /* burada yorgunluk hesaplaması olcak her 5 turda bir tum birimlerin  saldiri gucunu %10 dusurecek
    k ilk 1 olacak sekilde gelecek ve her 5 turda bir artacak 
    if(tur == 5k)
    {
        (unit + 4)->saldiri *= 0.90f;
        (unit + 5)->saldiri *= 0.90f;
        (unit + 6)->saldiri *= 0.90f;
        (unit + 7)->saldiri *= 0.90f;
        k++;
    }
   
    
    */
    if((strcmp(ork->kahraman,"Goruk_Vahsi")==0))
    {
        (units + 4)->saldiri *= 1.20f;  //orkdovuscusu
    }
    if((strcmp(ork->kahraman,"Vrog_Kafakiran")==0))
    {
       /* i yi basta 1 olarak fonksiyona gonder sonra i yi arttır
        if(tur == (100 / 15)*i)
        {    
             (units + 6)->saldiri *= 1.50f; //okcu
             i++;
        }*/
       
    }
   if((strcmp(ork->canavar,"Kara_Troll")==0))
    {
        (units + 7)->saldiri *= 1.20f;  //troller
    }
    if((strcmp(ork->canavar,"Ates_Iblisi")==0))
    {
        (units + 6)->saldiri *= 1.25f; //vargbinicisi
    }
    if(strcmp(ork->arastirma,"saldiri_gelistirmesi")==0)
    {
        if(ork->arastirma_degeri == 1)
        {
            (units + 4)->saldiri *= 1.10f;
            (units + 5)->saldiri *= 1.10f;
            (units + 6)->saldiri *= 1.10f;
            (units + 7)->saldiri *= 1.10f;


        }
        else if(ork->arastirma_degeri == 2)
        {
            (units + 4)->saldiri *= 1.20f;
            (units + 5)->saldiri *= 1.20f;
            (units + 6)->saldiri *= 1.20f;
            (units + 7)->saldiri *= 1.20f;
        }
        else if(ork->arastirma_degeri == 3)
        {
            (units + 4)->saldiri *= 1.30f;
            (units + 5)->saldiri *= 1.30f;
            (units + 6)->saldiri *= 1.30f;
            (units + 7)->saldiri *= 1.30f;
        }
       
       
    }
    if(strcmp(ork->arastirma,"elit_egitim")==0)
    {
        if(ork->arastirma_degeri == 1)
        {
            //tur sayisi 20nin katlari oldugunda etkili olsun
            /*
            (units + 4)->saldiri *= 1.50f;
            (units + 5)->saldiri *= 1.50f;
            (units + 6)->saldiri *= 1.50f;
            (units + 7)->saldiri *= 1.50f;
            */
        }
        else if(ork->arastirma_degeri == 2)
        {
            //tur sayisi 10un katlari oldugunda etkili olsun
            /*
            (units + 4)->saldiri *= 1.50f;
            (units + 5)->saldiri *= 1.50f;
            (units + 6)->saldiri *= 1.50f;
            (units + 7)->saldiri *= 1.50f;
            */
        }
        else if(ork->arastirma_degeri == 3)
        {
            //tur sayisi (100/15)in katlari oldugunda etkili olsun
            /*
            (units + 4)->saldiri *= 1.50f;
            (units + 5)->saldiri *= 1.50f;
            (units + 6)->saldiri *= 1.50f;
            (units + 7)->saldiri *= 1.50f;
            */
        }
    }

    
    
    mizrak_saldiri = (units + 4)->saldiri * (ork->mizrakcilar);
    orkDovuscileri_saldiri = (units + 5)->saldiri * (ork->orkDovuscileri);
    troller_saldiri = (units + 6)->saldiri * (ork->troller);
    varg_saldiri = (units + 7)->saldiri * (ork->vargBinicileri);
    net_saldiri = mizrak_saldiri + orkDovuscileri_saldiri + troller_saldiri + varg_saldiri;
    
    return net_saldiri;   
}


float savunma_ork( struct OrkLegi *ork, struct Unit *units,struct Hero *heroes, struct Creature *creatures,struct Research *researchs )
{


    float net_savunma, mizrak_savunma, orkDovuscileri_savunma, troller_savunma, varg_savunma;

    /* burada yorgunluk hesaplaması olcak her 5 turda bir tum birimlerin  saldiri gucunu %10 dusurecek
    k ilk 1 olacak sekilde gelecek ve her 5 turda bir artacak 
    if(tur == 5k)
    {
        (unit + 4)->savunma *= 0.90f;
        (unit + 5)->savunma *= 0.90f;
        (unit + 6)->savunma *= 0.90f;
        (unit + 7)->savunma *= 0.90f;
        k++;
    }
   
    
    */
    if((strcmp(ork->kahraman,"Thruk_Kemikkiran")==0))
    {
        (units + 7)->savunma *= 1.25f;  //troller
    }
    if((strcmp(ork->kahraman,"Ugar_Zalim")==0))
    {
        (units + 7)->savunma *= 1.10f;
        (units + 6)->savunma *= 1.10f;
        (units + 5)->savunma *= 1.10f;
        (units + 4)->savunma *= 1.10f;
    }
   if((strcmp(ork->canavar,"Golge_Kurtlari")==0))
    {
        (units + 6)->savunma *= 1.15f;//vargbinicisi
    }
    if((strcmp(ork->canavar,"Camur_Devleri")==0))
    {
         (units + 4)->savunma *= 1.25f;  //orkdovuscusu
    }

    if(strcmp(ork->arastirma,"savunma_ustaligi")==0)
    {
        if(ork->arastirma_degeri == 1)
        {
            (units + 4)->savunma *= 1.10f;
            (units + 5)->savunma *= 1.10f;
            (units + 6)->savunma *= 1.10f;
            (units + 7)->savunma *= 1.10f;
        }
       else if(ork->arastirma_degeri == 2)
        {
            (units + 4)->savunma *= 1.20f;
            (units + 5)->savunma *= 1.20f;
            (units + 6)->savunma *= 1.20f;
            (units + 7)->savunma *= 1.20f;
        }
        else if(ork->arastirma_degeri == 3)
        {
            (units + 4)->savunma *= 1.30f;
            (units + 5)->savunma *= 1.30f;
            (units + 6)->savunma *= 1.30f;
            (units + 7)->savunma *= 1.30f;
        }
       
    }

    
    
    mizrak_savunma = (units + 4)->savunma * (ork->mizrakcilar);
    orkDovuscileri_savunma = (units + 5)->savunma * (ork->orkDovuscileri);
    troller_savunma = (units + 6)->savunma * (ork->troller);
    varg_savunma = (units + 7)->savunma * (ork->vargBinicileri);
    net_savunma = mizrak_savunma + orkDovuscileri_savunma + troller_savunma + varg_savunma;
    return net_savunma;
}



int write_wartxt(const char *filename4, struct InsanImparatorlugu *insan, struct Unit *units,struct Hero *heroes,struct OrkLegi *ork,struct Creature *creatures,struct Research *researchs) {
    FILE *file4 = fopen(filename4, "w");
    if (!file4) {
        printf("Hata: Dosya '%s' bulunamadı.\n", filename4);
        return -1;
    }
    printf("%d",atoi(researchs->deger));
    printf("%d",atoi((researchs +1 )->deger));

     fprintf(file4,"%d",(units+1)->saldiri);
   float saldiri_sonuc_insan = saldiri_insan(insan,units,heroes,creatures,researchs);
   float savunma_sonuc_insan = savunma_insan(insan,units,heroes,creatures,researchs);
   printf("\ninsanlarin toplam  saldiri gucu :%.4f",saldiri_sonuc_insan);
   printf("\ninsanlarin toplam  savunma gucu :%.4f",savunma_sonuc_insan);
   float saldiri_sonuc_ork = saldiri_ork(ork,units,heroes,creatures,researchs);
    float savunma_sonuc_ork = savunma_ork(ork,units,heroes,creatures,researchs);
   printf("\norklarin toplam  saldiri gucu :%.4f",saldiri_sonuc_ork);
    printf("\norklarin toplam  savunma gucu :%.4f",savunma_sonuc_ork);

    printf("Dosyaya yazdirma işlemi basarili oldu.\n");
    return 0;
}

int main()
{
 struct Unit units[8];
 struct InsanImparatorlugu insan;
 struct Hero heroes[9];
 struct OrkLegi ork;
struct Creature creatures[11]; 
struct Research researchs[12];


const char *filename = "Files/unit_types.json";
const char *filename1 = "Files/heroes.json";
const char *filename2 = "Files/creatures.json";
const char *filename3 = "Files/research.json";

if (read_json(filename,units) == 0) {
    printf("Dosya okuma işlemi başarılı oldu.\n");
    }
    else
    {
        printf("Dosya okuma işlemi başarısız oldu.\n");
    }


if(hero_json(filename1,heroes) == 0) {
    printf("Dosya okuma işlemi başarılı oldu.\n");
    }
    else
    {
        printf("Dosya okuma işlemi başarısız oldu.\n");
    }

if(creatures_json(filename2,creatures) == 0) {
    printf("Dosya okuma işlemi başarılı oldu.\n");
    }
    else
    {
        printf("Dosya okuma işlemi başarısız oldu.\n");
    }

if(research_json(filename3,researchs) == 0) {
    printf("Dosya okuma işlemi başarılı oldu.\n");
    }
    else
    {
        printf("Dosya okuma işlemi başarısız oldu.\n");
    }


FILE *file = fopen("indirilen_senaryo.json", "r");
    if (!file) {
        perror("File opening failed");
        return EXIT_FAILURE;
    }

    // Dosyadan JSON verisini oku
    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);
    char *jsonString = malloc(length + 1);
    fread(jsonString, 1, length, file);
    fclose(file);
    jsonString[length] = '\0'; // Sonlandırıcı ekle

    
    memset(&insan, 0, sizeof(insan));
    parseInsanImparatorlugu(jsonString, &insan);

    memset(&ork, 0, sizeof(ork));
    parseOrkLegi(jsonString, &ork);

    
    const char *filename4 = "war.txt";
    if(write_wartxt(filename4,&insan,units,heroes,&ork,creatures,researchs)==0)
    {
        printf("Dosya oluşturuldu ve içeriği yazıldı.\n");
    }
    else
    {
        printf("Dosya oluşturulamadı.\n");
    }
    return 0;
}