#include <string.h>
#include <stdio.h>
#include <stdlib.h>


typedef struct 
{
    char* name[50];
    char* type[20]; //okçu, süvari vs
    int birlik_sayisi;
    int saldiri_gucu;
    int savunma_gucu;
    int max_saglik;
    double kritik_vurus_orani;
    int kalan_saglik;
    int count; //birimin sayısı
    int birlik_saldiri_gucu; 

} Birim;

Birim units[100];
int unit_count = 0;
int counth = 0;
int countc = 0;



typedef struct 
{
    char* name[50];
    double h_saldiri_bonus;
    double h_savunma_bonus;
} Kahraman;

Kahraman heroes[20];

typedef struct 
{
   char* name[50];
   double c_saldiri_bonus;
   double c_savunma_bonus;
} Canavar;

Canavar creatures[20];


int sum_of_hero_attack(Birim unit, Kahraman* hero)
{
    int toplam_guc = unit.birlik_sayisi * unit.saldiri_gucu; 

    if (hero != NULL)
    { 

        toplam_guc = (int)(toplam_guc * (1 + hero->h_saldiri_bonus)); 

    } 

    return toplam_guc; 

} 

int sum_of_creature_attack(Birim unit, Canavar* creature)
{
    int toplam_guc = unit.birlik_sayisi * unit.saldiri_gucu; 

    if (creature != NULL)
    { 

        toplam_guc = (int)(toplam_guc * (1 + creature->c_saldiri_bonus)); 

    } 

    return toplam_guc; 

} 


int sum_of_hero_defense(Birim unit, Kahraman* hero)
{
    int toplam_savunma = unit.birlik_sayisi * unit.savunma_gucu;

    if(hero != NULL)
    {
        toplam_savunma = (int)(toplam_savunma * (1 + hero->h_saldiri_bonus));

    }

    return toplam_savunma;

}

int sum_of_creature_defense(Birim unit, Canavar* creature)
{
    int toplam_savunma = unit.birlik_sayisi * unit.savunma_gucu;

    if(creature != NULL)
    {
        toplam_savunma = (int)(toplam_savunma * (1 + creature->c_savunma_bonus));

    }

    return toplam_savunma;

}


int calculate_critical_hit(Birim unit, int attack_number)
{
   int kritik_vurus = (int)(1.0 / unit.kritik_vurus_orani);
   
   if(attack_number % kritik_vurus == 0)
   {
     float toplam_zarar = unit.saldiri_gucu * unit.count;
     return toplam_zarar * 1.5;
   }

   return unit.saldiri_gucu * unit.count;
}


int main()
{
    read_json("unit_types.json");
    read_jsonh("heroes.json");

    for(int i=0; i< unit_count; i++)
    {
       int toplam_kahraman_gucu = sum_of_hero_attack(units[i], (counth > 0) ? &heroes[0]: NULL); //İlk kahramandan başlayarak 
       printf("%s biriminden toplam saldiri gucu: %d\n", units[i].name, toplam_kahraman_gucu);
    }

    for( int i=0; i< unit_count; i++)
    {
        int toplam_canavar_gucu = sum_of_creature_attack(units[i], (countc > 0) ? &creatures[0]: NULL);
        printf("%s biriminin toplam saldiri gucu: %d\n", units[i].name, toplam_canavar_gucu);
    }
    
    for(int i=0; i<unit_count; i++)
    {
        int toplam_kahraman_savumasi = sum_of_hero_defense(units[i], (counth > 0) ? &heroes: NULL);
        printf("%s biriminin toplam savunma gucu: %d\n", units[i].name, toplam_kahraman_savumasi);
    }

    for(int i=0; i<unit_count; i++)
    {
        int toplam_canavar_savunmasi = sum_of_creature_defense(units[i], (countc > 0) ? &creatures: NULL);
        printf("%s biriminin toplam savunma gucu: %d\n", units[i].name, toplam_canavar_savunmasi);
    }
    
    for (int i=0; i< unit_count; i++)
    {
        int saldiri_sayisi = (i + 1) * 10; 
        int zarar = calculate_critical_hit(units[i], saldiri_sayisi);
        printf("%s biriminin %d. saldiridaki verdigi hasar:. %d\n", units[i].name, saldiri_sayisi, zarar);
    }

   

    return 0;
}