#include "raylib.h"
#include <stdio.h>

#define ROWS 10
#define COLS 10
#define CELL_SIZE 60
#define HEALTH_BAR_WIDTH 8
#define HEALTH_BAR_HEIGHT (CELL_SIZE - 20)

typedef struct {
    int human_units;
    int orc_units;
    float human_health; // 0.0 ile 1.0 arasında
    float orc_health;   // 0.0 ile 1.0 arasında
} Cell;

void DrawCustomGrid(Cell grid[ROWS][COLS], Texture2D humanTexture, Texture2D orcTexture) {
    for (int row = 0; row < ROWS; row++) {
        for (int col = 0; col < COLS; col++) {
            int x = col * CELL_SIZE;
            int y = row * CELL_SIZE;

            // Hücrenin arka planı
            DrawRectangle(x, y, CELL_SIZE, CELL_SIZE, LIGHTGRAY);

            // Birlik sayılarını göster
            char text[20];
            sprintf(text, "H: %d\nO: %d", grid[row][col].human_units, grid[row][col].orc_units);
            DrawText(text, x + 5, y + 5, 10, BLACK);

            // İnsan birlikleri ve sağlık çubuğu
            if (grid[row][col].human_units > 0) {
                DrawTexture(humanTexture, x + 10, y + 20, WHITE);

                // Dolu (yeşil) kısım
                int filledHeight = HEALTH_BAR_HEIGHT * grid[row][col].human_health;
                DrawRectangle(x + 10, y + CELL_SIZE - 10 - filledHeight, HEALTH_BAR_WIDTH, filledHeight, GREEN);

                // Boş (kırmızı) kısım
                DrawRectangle(x + 10, y + CELL_SIZE - 10 - HEALTH_BAR_HEIGHT, HEALTH_BAR_WIDTH,
                              HEALTH_BAR_HEIGHT - filledHeight, RED);
            }

            // Ork birlikleri ve sağlık çubuğu
            if (grid[row][col].orc_units > 0) {
                DrawTexture(orcTexture, x + 30, y + 20, WHITE);

                // Dolu (yeşil) kısım
                int filledHeight = HEALTH_BAR_HEIGHT * grid[row][col].orc_health;
                DrawRectangle(x + 30, y + CELL_SIZE - 10 - filledHeight, HEALTH_BAR_WIDTH, filledHeight, GREEN);

                // Boş (kırmızı) kısım
                DrawRectangle(x + 30, y + CELL_SIZE - 10 - HEALTH_BAR_HEIGHT, HEALTH_BAR_WIDTH,
                              HEALTH_BAR_HEIGHT - filledHeight, RED);
            }
        }
    }
}

int main() {
    // Raylib'i başlat
    InitWindow(800, 600, "Izgara Tabanlı Savaş Görselleştirme");
    Texture2D humanTexture = LoadTexture("human.png"); // İnsan birimi resmi
    Texture2D orcTexture = LoadTexture("orc.png"); // Ork birimi resmi

    // 10x10'luk bir grid oluştur ve örnek değerler ata
    Cell grid[ROWS][COLS] = { 0 };
    grid[0][0] = (Cell){10, 5, 1.0f, 0.6f}; // Örneğin, 1. hücrede 10 insan (%100 sağlık) ve 5 ork (%60 sağlık) var
    grid[2][3] = (Cell){2, 3, 0.8f, 0.7f}; // 2. satır 3. sütunda 2 insan (%80 sağlık) ve 3 ork (%70 sağlık) var

    // Ana döngü
    while (!WindowShouldClose()) {
        // Ekranı temizle
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Izgarayı çiz
        DrawCustomGrid(grid, humanTexture, orcTexture);

        EndDrawing();
    }

    // Resimleri serbest bırak
    UnloadTexture(humanTexture);
    UnloadTexture(orcTexture);

    // Raylib'i kapat
    CloseWindow();

    return 0;
}
