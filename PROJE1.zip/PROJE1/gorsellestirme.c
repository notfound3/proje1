#include <raylib.h>
#include <stdio.h>
#include <stdlib.h>

void DrawGrid(int cellSize, int gridWidth, int gridHeight) {
    for (int x = 0; x <= gridWidth; x++) {
        DrawLine(x * cellSize, 0, x * cellSize, gridHeight * cellSize, DARKGRAY);
    }
    for (int y = 0; y <= gridHeight; y++) {
        DrawLine(0, y * cellSize, gridWidth * cellSize, y * cellSize, DARKGRAY);
    }
}

int main(void) {
    // Pencereyi başlat
    const int screenWidth = 800;
    const int screenHeight = 600;
    InitWindow(screenWidth, screenHeight, "Izgara Taban");

    SetTargetFPS(60); // FPS ayarla

    // Izgara ayarları
    int cellSize = 40; // Hücre boyutu
    int gridWidth = screenWidth / cellSize;  // Izgara genişliği
    int gridHeight = screenHeight / cellSize; // Izgara yüksekliği

    // Ana döngü
    while (!WindowShouldClose()) {
        // Ekranı temizle
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Izgarayı çiz
        DrawGrid(cellSize, gridWidth, gridHeight);

        EndDrawing();
    }

    // Kaynakları temizle
    CloseWindow();

    return 0;
}
